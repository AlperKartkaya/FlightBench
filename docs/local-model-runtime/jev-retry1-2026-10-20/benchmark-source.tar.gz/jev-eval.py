"""Authorized, serial live provider evaluations; credentials never enter artifacts."""
import hashlib,json,os,subprocess,sys,tarfile
from pathlib import Path
sys.path.insert(0,str(Path.cwd()))
from flightbench.runs import SOURCE_FILES,source_identity,now
ROOT=Path.cwd();OUT=ROOT/'docs/local-model-runtime/jev-retry1-2026-10-20';OUT.mkdir(parents=True,exist_ok=True)
identity=source_identity();archive=OUT/'benchmark-source.tar.gz'
assert not archive.exists()
with tarfile.open(archive,'w:gz') as t:
 for p in SOURCE_FILES:
  if p.is_file():t.add(p,arcname=p.relative_to(ROOT))
 t.add(Path(__file__),arcname='jev-eval.py')
(OUT/'source.json').write_text(json.dumps({'identity':identity,'archive_sha256':hashlib.sha256(archive.read_bytes()).hexdigest()},indent=2)+'\n')
status=[]
for model in ('jev-1.13.0','jev-1.14.0'):
 assert source_identity()['source_hash']==identity['source_hash']
 metadata={'name':model,'slug':model.replace('.','-')+'-arrival-s42','model':model,'provider':'TypeSafe','source_url':'https://docs.typesafe.ai/models','license':'proprietary hosted API','local':False,'controller_type':'ai','pricing_date':'2026-10-20','cost_methodology':'Recorded provider input/output token counts; USD estimates use $0.042 per million input tokens, output free. Uncollected terminal requests remain unknown.','campaign':{'id':'arrival-2026-10-20','model_parallelism':1,'per_model_episode_jobs':1,'shared_hardware':'Apple M1 Pro 16GB unified memory','provider_hardware':'Remote TypeSafe hardware not disclosed','scenario':'easy: seed-independent physical initialization','decision_hz':2,'time_scale':1.0,'realtime_response_policy':'apply-on-arrival','warmup':'Seven fixed-state live requests in earlier conformance; no local model loading.','order':'lockstep then realtime; sequential models','isolation':'No parallel benchmark model work; other desktop/agent activity possible.'}}
 p=OUT/f'{model}-metadata.json';p.write_text(json.dumps(metadata,indent=2)+'\n')
 output=ROOT/'leaderboard/submissions'/metadata['slug']
 cmd=[str(ROOT/'.venv/bin/python'),'-m','flightbench.benchmark','eval','--controller','jev','--model',model,'--metadata',str(p),'--modes','lockstep,realtime','--seeds','42','--jobs','1','--decision-hz','2','--time-scale','1.0','--realtime-response-policy','apply-on-arrival','--timeout','120','--output-dir',str(output)]
 entry={'model':model,'started_at':now(),'command':cmd,'status':'running'};status.append(entry)
 (OUT/'status.json').write_text(json.dumps(status,indent=2)+'\n')
 with (OUT/f'{model}-eval.log').open('x') as log:
  result=subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT)
 entry.update(status='complete' if result.returncode==0 else 'failed',finished_at=now(),exit_code=result.returncode)
 if result.returncode==0:subprocess.run([str(ROOT/'.venv/bin/python'),'-m','flightbench.leaderboard','validate',str(output/'submission.json')],check=True)
 (OUT/'status.json').write_text(json.dumps(status,indent=2)+'\n')
 print(model,entry['status'],flush=True)
