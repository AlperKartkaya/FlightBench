"""Serial, pinned, one-seed rerun. Only processes created here are stopped."""
import gzip
import hashlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import sys
import tarfile
import time
import urllib.request

ROOT = Path.cwd()
OUT = ROOT / 'docs/local-model-runtime/serial-2026-10-07'
WORK = ROOT / 'scratch/serial-2026-10-07'
PYTHON = ROOT / '.venv/bin/python'
sys.path.insert(0, str(ROOT))
from flightbench.runs import SOURCE_FILES, source_identity, now


def write(path, value):
    path.write_text(json.dumps(value, indent=2, allow_nan=False) + '\n')


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(8*1024*1024), b''): h.update(block)
    return h.hexdigest()


def get(url):
    with urllib.request.urlopen(url, timeout=2) as r: return json.load(r)


def stop(process):
    if process.poll() is None:
        os.killpg(process.pid, signal.SIGTERM)
        try: process.wait(timeout=30)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL); process.wait()


def verify(name, manifest):
    if name in ('nimble', 'openthai'):
        store = Path.home()/'.ollama/models'
        sub = 'library/nimble/9b-q4_K_M' if name == 'nimble' else 'iapp/openthai-systemone/0.8b-q8_0'
        path = store/'manifests/registry.ollama.ai'/sub
        assert sha(path) == manifest['model_manifest_sha256'], path
        for layer in json.loads(path.read_text())['layers']:
            blob = store/'blobs'/layer['digest'].replace(':','-')
            assert sha(blob) == layer['digest'].split(':')[1], blob
    else:
        if name == 'kev':
            paths = list((ROOT/'scratch/huggingface/hub').glob('models--*/snapshots/*/*'))
        else: paths = list((ROOT/f'scratch/{name}-runtime/model').glob('*'))
        for name_, info in manifest['files'].items():
            assert any(p.name == name_ and sha(p) == info['sha256'] for p in paths if p.is_file()), name_
        rev = subprocess.check_output(['git','-C',f'scratch/model-sources/{name}','rev-parse','HEAD'],text=True).strip()
        assert rev == manifest['source_revision'], rev


base_env = {k: os.environ[k] for k in ('HOME','PATH','TMPDIR') if k in os.environ}
base_env.update(HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', TOKENIZERS_PARALLELISM='false',
                OMP_NUM_THREADS='2', MKL_NUM_THREADS='2', VECLIB_MAXIMUM_THREADS='2', PYTHONUNBUFFERED='1')
for port in (11435,11436,11437,11439):
    with socket.socket() as sock:
        if sock.connect_ex(('127.0.0.1',port)) == 0: raise RuntimeError(f'Port {port} occupied; refusing interference')
identity = source_identity()
archive = OUT/'benchmark-source.tar.gz'
if archive.exists(): raise FileExistsError(archive)
with tarfile.open(archive,'w:gz') as tar:
    for p in SOURCE_FILES:
        if p.is_file(): tar.add(p,arcname=p.relative_to(ROOT))
    tar.add(Path(__file__),arcname='serial-runner.py')
    tar.add(ROOT/'examples/local/decider_gguf_server.py',arcname='examples/local/decider_gguf_server.py')
write(OUT/'source.json', {'identity':identity,'archive_sha256':sha(archive)})
awake = subprocess.Popen(['/usr/bin/caffeinate','-i'],start_new_session=True)
status=[]
try:
 for name in ('kev','openthai','decider','von','nimble'):
    entry={'model':name,'started_at':now(),'status':'starting'};status.append(entry);write(OUT/'status.json',status)
    manifest=json.loads((ROOT/f'docs/local-model-runtime/{name}-manifest.json').read_text())
    server=None
    try:
      verify(name,manifest)
      env=base_env.copy()
      if name == 'kev':
        port=11436; route='/v1/models'
        env.update(HF_HOME=str(ROOT/'scratch/huggingface'),KEV_BACKEND='mlx',KEV_DATE_FACTS='0',KEV_TRUNCATE_STATES='0',KEV_PREFIX_CACHE='4')
        cmd=[str(ROOT/'scratch/kev-runtime/.venv/bin/python'),'-m','kev.serve','--run','jaredpalmer/kev-0.8b@'+manifest['model_revision'],'--host','127.0.0.1','--port',str(port)]
      elif name == 'decider':
        port=11439;route='/'
        cmd=[str(ROOT/'scratch/decider-runtime/.venv/bin/python'),'examples/local/decider_gguf_server.py','scratch/decider-runtime/model']
        manifest['runtime_wrapper_sha256']=sha(ROOT/'examples/local/decider_gguf_server.py')
        manifest['runtime_wrapper_note']='Published loopback wrapper; actual wrapper included in campaign source archive.'
      elif name == 'von':
        port=11437;route='/health'
        env.update(VON_CHECKPOINT_DIR=str(ROOT/'scratch/von-runtime/model'),HF_HOME=str(ROOT/'scratch/von-runtime/hf-home'))
        cmd=[str(ROOT/'scratch/von-runtime/.venv/bin/von'),'serve','--host','127.0.0.1','--port',str(port),'--model','von-1.3','--device','mps','--on-overflow','refuse','--no-chains']
        manifest['backend']='PyTorch MPS; CPU helper threads 2; no CPU fallback requested'
      else:
        port=11435;route='/api/version'
        env.update(OLLAMA_HOST=f'127.0.0.1:{port}',OLLAMA_NO_CLOUD='1',OLLAMA_NUM_PARALLEL='1',OLLAMA_MAX_LOADED_MODELS='1',OLLAMA_CONTEXT_LENGTH='8192',OLLAMA_KV_CACHE_TYPE='q8_0',OLLAMA_FLASH_ATTENTION='1')
        cmd=[str(ROOT/'scratch/ollama-0.35.0/ollama'),'serve']
      endpoint=f'http://127.0.0.1:{port}'
      manifest['slug'] += '-serial-s42'
      manifest['campaign']={'id':'serial-2026-10-07','model_parallelism':1,'per_model_episode_jobs':1,
        'shared_hardware':'Apple M1 Pro 16GB unified memory','scenario':'easy: seed-independent physical initialization',
        'decision_hz':2,'time_scale':1.0,'warmup':'One complete canonical initial-state request before both episodes; retained separately.',
        'order':'lockstep then realtime; one model server at a time; host kept awake with caffeinate -i',
        'isolation':'Other desktop/agent activity possible; no other benchmark model jobs.'}
      metadata=OUT/f'{name}-metadata.json';write(metadata,manifest)
      env.update(FLIGHTBENCH_SYSTEMONE_URL=endpoint,FLIGHTBENCH_LOCAL_METADATA=str(metadata))
      entry.update(command=cmd,environment={k:v for k,v in env.items() if k not in base_env},status='warming')
      write(OUT/'status.json',status)
      with (WORK/f'{name}-server.log').open('w') as log:
        server=subprocess.Popen(cmd,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
        for _ in range(180):
          if server.poll() is not None: raise RuntimeError('server exited; see server log')
          try: runtime=get(endpoint+route);break
          except OSError:time.sleep(1)
        else:raise TimeoutError('runtime readiness timed out')
        write(OUT/f'{name}-runtime-before.json',runtime)
        warmup="""import json,time
from pathlib import Path
from flightbench.local import SystemOneController
from flightbench.environment import FixedWingLandingEnv
from flightbench.temporal import TelemetryHistory
e=FixedWingLandingEnv();o,_=e.reset(seed=42);h=TelemetryHistory();h.add(o);o['temporal']=h.features(o)
c=SystemOneController(MODEL);t=time.perf_counter();a=c.decide(o)
Path(OUTPUT).write_text(json.dumps({'latency_ms':(time.perf_counter()-t)*1000,'decision_info':c.last_decision,'command':a.model_dump()},indent=2,allow_nan=False)+'\\n');e.close()
""".replace('MODEL',repr(manifest['model'])).replace('OUTPUT',repr(str(OUT/f'{name}-warmup.json')))
        subprocess.run([str(PYTHON),'-c',warmup],env=env,check=True,timeout=180)
        if name in ('nimble','openthai'):
          write(OUT/f'{name}-gpu-residency.json',get(endpoint+'/api/ps'))
        assert source_identity()['source_hash'] == identity['source_hash'], 'source changed before evaluation'
        entry['status']='evaluating';write(OUT/'status.json',status)
        output=ROOT/'leaderboard/submissions'/manifest['slug']
        with (WORK/f'{name}-eval.log').open('w') as log:
          subprocess.run([str(PYTHON),'-m','flightbench.benchmark','eval','--controller','systemone','--model',manifest['model'],
            '--metadata',str(metadata),'--modes','lockstep,realtime','--seeds','42','--jobs','1','--decision-hz','2','--time-scale','1.0','--timeout','120','--output-dir',str(output)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run([str(PYTHON),'-m','flightbench.leaderboard','validate',str(output/'submission.json')],env=env,check=True)
        write(OUT/f'{name}-runtime-after.json',get(endpoint+route))
        entry.update(status='complete',submission=str(output.relative_to(ROOT)/'submission.json'),finished_at=now())
        print(name,'complete',flush=True)
    except Exception as exc:
      entry.update(status='failed',error=f'{type(exc).__name__}: {exc}',finished_at=now())
      print(name,entry['error'],flush=True)
    finally:
      if server:stop(server)
      write(OUT/'status.json',status)
finally:
 stop(awake)
